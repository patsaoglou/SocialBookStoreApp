package com.SE2024.SocialBookStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialBookStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialBookStoreApplication.class, args);
	}

}
