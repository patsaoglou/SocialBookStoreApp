package com.SE2024.SocialBookStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialBookStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
